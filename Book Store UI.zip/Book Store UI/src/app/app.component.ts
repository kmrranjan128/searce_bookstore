import { Component } from '@angular/core';
import {FormControl,FormGroup} from '@angular/forms';
import {AppService} from './app.service'
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import {Http, Response} from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AppService]
})
export class AppComponent {
	options: string[];
	book_search:string[];
	book_id:string;

	searchTerm :FormControl = new FormControl();
	myControl: FormControl = new FormControl();
	
	  public userName;
	  showAdminAccess = false;
	  showListView = false;
	  showNolistData = false;
	  showEditView = false;
	  ShowDefault = true;
	  editBookDetail = {
		  book_name:'',
		  book_author:'',
		  book_desc:''
	  };
	  selectedbook;


   constructor(private service: AppService,private http: Http){
		this.http.request('http://127.0.0.1:8000/book_filter').subscribe((res: Response) => {
		this.options= res.json().book_filter;
   });
   localStorage.clear();
}

getPosts(book_search){
	
	this.selectedbook = book_search;
	this.http.request('http://127.0.0.1:8000/book_search?book='+book_search+'').subscribe((res: Response) => {
		this.book_search= res.json().book_information;
		
		
		if(this.book_search){
			if(this.book_search.length > 0){
				this.showListView = true ;
				this.showNolistData = false ;
			} else {
				this.showNolistData = true ;
				this.showListView = false ;
			}
		}
		
   });
}

onClickSubmit(data) {
	  if(data.username === "admin" && data.passwd === "admin"){
		
		localStorage.setItem('username', data.username);
		this.userName = data.username;
		this.showAdminAccess = true;
	  }
      else{
		
		alert("Please check your username and password");
	  }
 }


 editBook(index,bookDetail){
	
	this.showEditView = true;
	this.ShowDefault = false;
	this.editBookDetail = bookDetail;
 }


 deleteBook(id){
	



	 this.http.get('http://127.0.0.1:8000/book_delete/?bookid='+this.book_search[0]['book_id']+'').subscribe((res: Response) =>{
		

		this.http.request('http://127.0.0.1:8000/book_search?book='+this.selectedbook+'').subscribe((res: Response) => {
		this.book_search= res.json().book_information;
		
		if(this.book_search){
			if(this.book_search.length > 0){
				this.showListView = true ;
				this.showNolistData = false ;
			} else {
				this.showNolistData = true ;
				this.showListView = false ;
			}
		}
		
   });
  
	})


	// this.http.d



  


 }


 backPage(){
	this.showEditView = false;
	this.ShowDefault = true;	  
 }


 logout(){
	localStorage.clear();
	this.showAdminAccess = false;
	this.showListView = false ;
	this.showNolistData = false; 
	// this.options =[] ;
	// this.book_search =[];
 }

 updateBook(updateData){


	var body ={"book_name":this.selectedbook,
	
	"book_update": [
	  { "book_id":""+updateData.book_id+"",
		  
	  "book_name":updateData.book_name,
		  
	  "book_author":updateData.book_author,
		  
	  "book_desc":updateData.book_desc
	  
	  }
	  ]
	   
  }


	// var formCheck = {'book_name' : this.selectedbook , 'book_update': [updateData]}

	 
   
  this.http.post('http://127.0.0.1:8000/book_update',body).subscribe((res: Response) =>{
	  console.log('120_UpdateResponse',res);

  })

  



}


}
