from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.decorators import api_view
from django.http import JsonResponse
from book.models import BookStore,Book
import os
import random
import requests
import base64
from django.db import connection
from django.db.models import Q
from base64 import decodestring
# Create your views here.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cursor = connection.cursor()

@api_view(['POST'])
def book_insert(request):
	resp=''
	if request.method == "POST":
		try:
			ran_num = ''.join(random.choice('0123456789') for _ in range(6))
			book_info = request.data
			search_book = Book.objects.filter(book_name=book_info['book_name'])
			image_url_path = 'http://127.0.0.1:8000/static/book_images/' + ran_num + '.jpg'
			path = os.path.join(BASE_DIR, 'static/book_images/')
			imgdata = base64.b64decode(str(book_info['image']))
			file_path = path + ran_num + '.jpg'
			if not search_book:
				with open(file_path, 'wb') as f:
					f.write(imgdata)
				book = Book(book_name=book_info["book_name"])
				book.save()
				
				book_store = BookStore(book_name=book,book_num=ran_num,book_name_ref=book_info["book_name"], book_type=book_info["book_type"],
									   book_author=book_info["book_author"], book_desc=book_info["book_desc"],
									   book_pic=str(image_url_path))
				book_store.save()
				resp = {"status code": "100-10002", "description": "Book sucessfully saved"}


			else:
				b_name = Book.objects.get(book_name=book_info['book_name'])
				with open(file_path, 'wb') as f:
					f.write(imgdata)

				book_store = BookStore(book_name=b_name,book_num=ran_num, book_name_ref=book_info["book_name"],book_type=book_info["book_type"],
									   book_author=book_info["book_author"], book_desc=book_info["book_desc"],
									   book_pic=str(image_url_path))
				book_store.save()
				resp = {"status code": "100-10006", "description": "Book sucessfully saved"}

		except Exception as e:
			print(e)

	return JsonResponse(resp)


	#BookStore("1",'java','')

@api_view(['GET'])
def book_delete(request):
	resp = ''
	if request.method == "GET":
		b_delete = request.GET['bookid']
		try:
			book_data = BookStore.objects.filter(book_name_ref="python")
			for i in book_data:
				print(i.book_name_ref)
			cursor.execute('DELETE FROM book_bookstore WHERE book_id='+b_delete+'')
			#DELETE FROM Customers WHERE CustomerName='Alfreds Futterkiste';
			resp = {"status code": "100-10007", "description": "Book sucessfully deleted"}

		except Exception as e:
			resp = {"status code": "100-10008", "description": "Bookid is invalid"}
	return JsonResponse(resp)



@api_view(['POST'])
def book_update(request):
	resp = ''
	if request.method == "POST":
		book_info = request.data

		book_update = Book.objects.get(book_name=book_info['book_name'])
		try:
			if not book_update:
				resp = {"status code": "100-10003", "description": "Book is not available"}
			else:
				
				book_upd=BookStore.objects.filter(pk=book_info['book_update'][0]['book_id'])
				for i in book_upd:
					
					cursor.execute("UPDATE book_bookstore SET book_author = '"+book_info['book_update'][0]['book_author']+"' WHERE book_id ='"+book_info['book_update'][0]['book_id']+"'")
				
				resp = {"status code": "100-10004", "description": "Book sucessfully updated"}
		except Exception as e:
			resp = {"status code": "100-10008", "description": "Please Enter correct book name and book id"}
		return JsonResponse(resp)




@api_view(['GET'])
def book_search(request):

	resp=''
	b_info = []
	if request.method == "GET":
		b_search = request.GET['book']
		#book_info = request.data
		try:
			book_search = Book.objects.get(book_name=b_search)
			if not book_search:
				resp = {"status code": "100-10002", "description": "Book is not available"}
			else:
				print("wrong")
				query=cursor.execute("select * from book_bookstore where book_name_ref='"+b_search+"'")
				for i in query:
					b_info.append({"book_id":i[0],"book_number":i[8],"book_name":i[7],"book_type":i[5],"book_author":i[2],"book_desc":i[4],"image":i[6]})
				# book_data = BookStore.objects.all()
				# for i in book_data:
				# 	#print(i.book_name_ref)

				# 	b_info.append({"book_id":i.book_id,"book_number":i.book_num,"book_name":i.book_name_ref,"book_type":i.book_type,"book_author":i.book_author,"book_desc":i.book_desc,"image":i.book_pic})
			resp={"status code": "100-10003","book_information":b_info}
		except Exception as e:
			resp={"status code": "100-10003","description":"Book is not available"}
	return JsonResponse(resp)


@api_view(['GET'])
def book_filter(request):
	resp=''
	b_filter = []
	if request.method == "GET":
		book_info = request.data
		try:
			book_filter=Book.objects.all()
			for i in book_filter:
				b_filter.append({"book_name":i.book_name})
			resp = {"status_code": "100-10003", "book_filter": b_filter}
		except Exception as e:
			print(e)
	return JsonResponse(resp)

def home(request):
	pass
	
